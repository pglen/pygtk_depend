PyGObject is a set of bindings for the glib, gobject and gio libraries.
It provides an object oriented interface that is slightly higher level than
the C one. It automatically does all the type casting and reference
counting that you would have to do normally with the C API. You can
find out more on the official homepage, http://www.pygtk.org/

